export default function AnalyticsPage() {
  return (
    <div>
      <h2 className="text-3xl font-semibold mb-8">Analytics</h2>
      <p className="text-muted-foreground">Coming soon...</p>
    </div>
  );
}
